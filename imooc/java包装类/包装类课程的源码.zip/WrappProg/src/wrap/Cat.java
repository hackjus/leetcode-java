package wrap;

public class Cat {
	//成员属性
	String name;
	Integer month;
	Double weight;
	
}
