package wrap;

public class CatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//实例化对象
		Cat one=new Cat();
		//测试输出
		System.out.println("小猫的昵称："+one.name);
		System.out.println("小猫的年龄："+one.month);
		System.out.println("小猫的体重："+one.weight);
	}

}
