package com.imooc.test;

import com.imooc.animal.Cat;

public class TestTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Cat one=new Cat();
		Cat one=new Cat("花花",2);
		System.out.println(one.temp);
	}

}
